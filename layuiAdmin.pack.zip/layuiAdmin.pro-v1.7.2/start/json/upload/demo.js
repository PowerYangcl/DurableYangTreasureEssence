{
  "code": 0,
  "msg": "",
  "data": {
    "src": "https://sentsin.gitee.io/res/images/layui/avatar.png"
  }
}