{
  "code": 0
  ,"msg": ""
  ,"data": {
    "username": "tester"
    ,"sex": "男"
    ,"role": 1
  }
}